#!/bin/sh
./gradlew build && echo "Готово: build/libs/"
