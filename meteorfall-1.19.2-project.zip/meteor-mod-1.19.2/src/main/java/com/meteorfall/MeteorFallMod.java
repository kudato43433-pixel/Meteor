package com.meteorfall;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class MeteorFallMod implements ModInitializer {
	public static final String MOD_ID = "meteorfall";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/** Высота старта метеорита над землёй, в блоках. */
	private static final double START_HEIGHT = 70.0;
	/** Скорость падения, блоков за тик. */
	private static final double FALL_SPEED = 2.0;

	private MeteorConfig config;
	private int intervalTicks;
	private int cleanupCounter = 0;

	/** Сколько тиков прошло с последнего метеорита у каждого игрока. */
	private final Map<UUID, Integer> timers = new HashMap<>();
	private final List<Meteor> meteors = new ArrayList<>();

	@Override
	public void onInitialize() {
		config = MeteorConfig.load();
		intervalTicks = config.intervalTicks();
		ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);
		LOGGER.info("Meteor Fall: метеорит на каждого игрока раз в {} мин.", config.intervalMinutes);
	}

	private void onServerTick(MinecraftServer server) {
		tickPlayers(server);
		tickMeteors();

		// Раз в минуту чистим таймеры вышедших игроков.
		if (++cleanupCounter >= 1200) {
			cleanupCounter = 0;
			timers.keySet().removeIf(uuid -> server.getPlayerList().getPlayer(uuid) == null);
		}
	}

	private void tickPlayers(MinecraftServer server) {
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			if (!player.isAlive() || player.isSpectator()) {
				continue;
			}
			ServerLevel level = (ServerLevel) player.level;
			if (config.overworldOnly && level.dimension() != Level.OVERWORLD) {
				continue;
			}

			int ticks = timers.merge(player.getUUID(), 1, Integer::sum);
			if (ticks >= intervalTicks) {
				// Если место падения не загружено, попробуем снова на следующем тике.
				if (spawnMeteor(level, player)) {
					timers.put(player.getUUID(), 0);
				}
			}
		}
	}

	private boolean spawnMeteor(ServerLevel level, ServerPlayer player) {
		RandomSource random = level.getRandom();

		double angle = random.nextDouble() * Math.PI * 2.0;
		double distance = config.minDistance + random.nextDouble() * (config.maxDistance - config.minDistance);
		double targetX = player.getX() + Math.cos(angle) * distance;
		double targetZ = player.getZ() + Math.sin(angle) * distance;

		BlockPos probe = new BlockPos((int) Math.floor(targetX), (int) Math.floor(player.getY()), (int) Math.floor(targetZ));
		if (!level.hasChunkAt(probe)) {
			return false;
		}

		int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING, probe.getX(), probe.getZ());

		// Метеорит летит по диагонали: горизонтальный снос случайный.
		double driftAngle = random.nextDouble() * Math.PI * 2.0;
		double driftSpeed = 0.4 + random.nextDouble() * 0.4;
		double vx = Math.cos(driftAngle) * driftSpeed;
		double vz = Math.sin(driftAngle) * driftSpeed;
		double flightTicks = START_HEIGHT / FALL_SPEED;

		double startX = targetX - vx * flightTicks;
		double startZ = targetZ - vz * flightTicks;
		double startY = ground + START_HEIGHT;

		meteors.add(new Meteor(level, startX, startY, startZ, vx, -FALL_SPEED, vz));

		level.playSound((Player) null, targetX, ground, targetZ,
			SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.WEATHER, 6.0f, 0.5f);

		if (config.announce) {
			player.sendSystemMessage(Component.literal("☄ Метеорит падает совсем рядом! Берегитесь!")
				.withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
		}
		return true;
	}

	private void tickMeteors() {
		Iterator<Meteor> it = meteors.iterator();
		while (it.hasNext()) {
			Meteor m = it.next();
			ServerLevel level = m.level;

			m.x += m.vx;
			m.y += m.vy;
			m.z += m.vz;

			BlockPos pos = new BlockPos((int) Math.floor(m.x), (int) Math.floor(m.y), (int) Math.floor(m.z));
			if (!level.hasChunkAt(pos)) {
				it.remove();
				continue;
			}

			// Огненный шлейф.
			level.sendParticles(ParticleTypes.FLAME, m.x, m.y, m.z, 14, 0.6, 0.6, 0.6, 0.03);
			level.sendParticles(ParticleTypes.LARGE_SMOKE, m.x, m.y, m.z, 8, 0.8, 0.8, 0.8, 0.02);
			level.sendParticles(ParticleTypes.LAVA, m.x, m.y, m.z, 3, 0.5, 0.5, 0.5, 0.0);

			int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING, pos.getX(), pos.getZ());
			if (m.y <= ground + 0.5) {
				impact(level, m.x, ground, m.z);
				it.remove();
			}
		}
	}

	private void impact(ServerLevel level, double x, int groundY, double z) {
		Explosion.BlockInteraction interaction = config.griefing
			? Explosion.BlockInteraction.DESTROY
			: Explosion.BlockInteraction.NONE;
		level.explode(null, x, groundY, z, config.explosionPower, interaction);

		level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, groundY + 1, z, 1, 0.0, 0.0, 0.0, 0.0);
		level.sendParticles(ParticleTypes.LAVA, x, groundY + 1, z, 40, 2.0, 1.0, 2.0, 0.0);

		BlockPos column = new BlockPos(Mth.floor(x), groundY, Mth.floor(z));
		int craterTop = level.getHeight(Heightmap.Types.MOTION_BLOCKING, column.getX(), column.getZ());

		// В центре кратера остаётся раскалённое ядро метеорита.
		level.setBlockAndUpdate(new BlockPos(column.getX(), craterTop - 1, column.getZ()),
			Blocks.MAGMA_BLOCK.defaultBlockState());

		if (config.loot) {
			dropLoot(level, x, craterTop + 1, z);
		}
	}

	private void dropLoot(ServerLevel level, double x, double y, double z) {
		RandomSource random = level.getRandom();

		drop(level, x, y, z, new ItemStack(Items.IRON_INGOT, 6 + random.nextInt(9)));
		drop(level, x, y, z, new ItemStack(Items.GOLD_INGOT, 3 + random.nextInt(6)));
		drop(level, x, y, z, new ItemStack(Items.COPPER_INGOT, 4 + random.nextInt(9)));

		if (random.nextFloat() < 0.5f) {
			drop(level, x, y, z, new ItemStack(Items.DIAMOND, 1 + random.nextInt(3)));
		}
		if (random.nextFloat() < 0.2f) {
			drop(level, x, y, z, new ItemStack(Items.NETHERITE_SCRAP, 1));
		}
	}

	private void drop(ServerLevel level, double x, double y, double z, ItemStack stack) {
		level.addFreshEntity(new ItemEntity(level, x, y, z, stack));
	}

	/** Падающий метеорит. */
	private static final class Meteor {
		final ServerLevel level;
		double x, y, z;
		final double vx, vy, vz;

		Meteor(ServerLevel level, double x, double y, double z, double vx, double vy, double vz) {
			this.level = level;
			this.x = x;
			this.y = y;
			this.z = z;
			this.vx = vx;
			this.vy = vy;
			this.vz = vz;
		}
	}
}
