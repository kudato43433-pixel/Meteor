@echo off
call gradlew.bat build
if errorlevel 1 (echo Ошибка сборки & pause & exit /b 1)
echo.
echo Готово: смотрите папку build\libs
pause
